import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Badge } from "@/components/ui/badge";
import { Eye, Heart } from "lucide-react";
import { Link } from "react-router-dom";
import Autoplay from "embla-carousel-autoplay";

interface Article {
  id: string;
  title: string;
  summary: string;
  category: "K-POP" | "MCU";
  published_at: string;
  views: number;
  likes: number;
  keywords: string[];
  thumbnail: string | null;
  author_name: string;
  author_avatar: string;
}

interface FeaturedSectionProps {
  articles: Article[];
}

const FeaturedSection = ({ articles }: FeaturedSectionProps) => {
  return (
    <section className="w-full py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-bold mb-8 font-display">Featured</h2>
          <Carousel
            opts={{
              align: "start",
              loop: true,
            }}
            plugins={[
              Autoplay({
                delay: 5000,
              }),
            ]}
            className="w-full"
          >
            <CarouselContent>
              {articles.map((article) => (
                <CarouselItem key={article.id}>
                  <Link to={`/article/${article.id}`}>
                    <Card className="border-0 shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                      <CardContent className="p-0">
                        <div className="relative aspect-[2.5/1]">
                          <img
                            src={article.thumbnail || "/placeholder.svg"}
                            alt={article.title}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
                          <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
                            <Badge
                              className={
                                article.category === "K-POP"
                                  ? "bg-kpop-600 hover:bg-kpop-700 text-white mb-4"
                                  : "bg-mcu-600 hover:bg-mcu-700 text-white mb-4"
                              }
                            >
                              {article.category}
                            </Badge>
                            <h3 className="text-3xl font-bold mb-3 leading-tight font-display">
                              {article.title}
                            </h3>
                            <p className="text-lg mb-4 text-white/90">
                              {article.summary}
                            </p>
                            <div className="flex items-center gap-4 text-sm text-white/80">
                              <span className="flex items-center gap-1">
                                <Eye className="h-4 w-4" />
                                {article.views.toLocaleString()}
                              </span>
                              <span className="flex items-center gap-1">
                                <Heart className="h-4 w-4" />
                                {article.likes}
                              </span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="left-4" />
            <CarouselNext className="right-4" />
          </Carousel>
        </div>
      </div>
    </section>
  );
};

export default FeaturedSection;
