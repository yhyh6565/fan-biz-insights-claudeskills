import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Eye, Heart, Calendar } from "lucide-react";
import { cn } from "@/lib/utils";

interface ArticleListCardProps {
  id: string;
  title: string;
  summary: string;
  category: "K-POP" | "MCU";
  date: string;
  views: number;
  likes: number;
  keywords: string[];
  thumbnail: string;
  author: {
    name: string;
    avatar: string;
  };
}

const ArticleListCard = ({
  id,
  title,
  summary,
  category,
  date,
  views,
  likes,
  keywords,
  thumbnail,
  author,
}: ArticleListCardProps) => {
  return (
    <Link to={`/article/${id}`}>
      <Card className="flex flex-col md:flex-row gap-6 p-6 hover:shadow-xl transition-all duration-300 group border-border/50 hover:border-primary/30">
        {/* Thumbnail */}
        <div className="flex-shrink-0 overflow-hidden rounded-lg">
          <img
            src={thumbnail}
            alt={title}
            className="w-full md:w-48 h-48 object-cover transition-transform duration-500 group-hover:scale-110"
          />
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col gap-3">
          {/* Category Badge */}
          <Badge
            variant="secondary"
            className={cn(
              "w-fit text-xs font-medium",
              category === "K-POP"
                ? "bg-kpop-100 text-kpop-700 hover:bg-kpop-200"
                : "bg-mcu-100 text-mcu-700 hover:bg-mcu-200"
            )}
          >
            {category}
          </Badge>

          {/* Title */}
          <h3 className="text-2xl font-bold line-clamp-2 group-hover:text-primary transition-colors font-display">
            {title}
          </h3>

          {/* Author & Date */}
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <span className="font-medium">By {author.name}</span>
            <span>·</span>
            <span className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {date}
            </span>
          </div>

          {/* Summary */}
          <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">
            {summary}
          </p>

          {/* Keywords */}
          <div className="flex flex-wrap gap-2 mt-1">
            {keywords.slice(0, 3).map((keyword) => (
              <span
                key={keyword}
                className="text-xs px-3 py-1 rounded-full bg-muted text-muted-foreground border border-border"
              >
                {keyword}
              </span>
            ))}
          </div>

          {/* Meta Info */}
          <div className="flex items-center gap-4 text-sm text-muted-foreground mt-auto pt-2">
            <span className="flex items-center gap-1">
              <Eye className="h-4 w-4" />
              {views.toLocaleString()}
            </span>
            <span className="flex items-center gap-1">
              <Heart className="h-4 w-4" />
              {likes}
            </span>
          </div>
        </div>
      </Card>
    </Link>
  );
};

export default ArticleListCard;
